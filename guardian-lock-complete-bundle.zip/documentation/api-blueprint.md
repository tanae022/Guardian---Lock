API Blueprint

POST /guardian/check
POST /alerts/send
GET /dashboard/incidents