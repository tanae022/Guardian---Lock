Alert Templates

Push, SMS, and Email templates for parents.