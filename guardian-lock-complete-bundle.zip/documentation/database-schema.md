Database Schema
Parents, Children, Incidents, Subscriptions